<?php
include_once "\143\x6c\x61\163\x73\56\x70\150\x70"; $auth = new User(); $auth->logout(); header("\114\157\x63\141\x74\151\x6f\156\72\40\x6c\157\147\151\x6e");

