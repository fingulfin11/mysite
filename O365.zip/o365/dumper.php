<?php
/**
 * dumper.php — eval-free PHP deobfuscator.
 *
 * Catches the strings passed to eval() at runtime via var_dump, never calling
 * eval() from our own code. Handles nested eval-chain obfuscation by rewriting
 * eval(X) -> eval(__catch(X)) and letting the original program drive recursion.
 *
 * Usage:
 *   php dumper.php <file.php>                    deobfuscate one file in-place (.bak kept)
 *   php dumper.php <file.php> -o <dir>           write output to <dir>/<file>, original kept
 *   php dumper.php <file.php> --stages           also save every intermediate layer
 *   php dumper.php <dir> --recursive             walk a directory tree
 *   php dumper.php <dir> -r -o out --stages      everything at once
 *
 * Flags:
 *   -o, --output-dir DIR   Write output to DIR instead of overwriting in place.
 *                          For --recursive, DIR mirrors the source tree.
 *   -r, --recursive        Process every .php file under the given directory.
 *                          Skips vendor/, node_modules/, .git/, and similar.
 *   --stages               Save every intermediate eval layer alongside the output.
 *   --no-color             Disable colored output (also honors NO_COLOR env var).
 *   -h, --help             Show this help.
 */

// ---------- color helpers --------------------------------------------------
$USE_COLOR = (function () {
    if (getenv('NO_COLOR') !== false) return false;
    if (!stream_isatty(STDERR)) return false;
    return true;
})();

function set_color(bool $on): void {
    global $USE_COLOR;
    $USE_COLOR = $on;
}

function c(string $code, string $text): string {
    global $USE_COLOR;
    return $USE_COLOR ? "\033[{$code}m{$text}\033[0m" : $text;
}

function bold(string $s):  string { return c('1', $s); }
function dim(string $s):   string { return c('2', $s); }
function red(string $s):   string { return c('31', $s); }
function green(string $s): string { return c('32', $s); }
function yellow(string $s):string { return c('33', $s); }
function blue(string $s):  string { return c('34', $s); }
function cyan(string $s):  string { return c('36', $s); }

function info(string $msg): void { fwrite(STDERR, cyan('→ ')   . $msg . "\n"); }
function ok(string $msg):   void { fwrite(STDERR, green('✓ ')  . $msg . "\n"); }
function warn(string $msg): void { fwrite(STDERR, yellow('! ') . $msg . "\n"); }
function fail(string $msg): void { fwrite(STDERR, red('✗ ')    . $msg . "\n"); }

// ---------- help -----------------------------------------------------------
function show_help(): void {
    $src = file_get_contents(__FILE__);
    if (preg_match('#/\*\*(.*?)\*/#s', $src, $m)) {
        // Strip the leading ` * ` from each docblock line, but preserve blanks.
        $lines = explode("\n", $m[1]);
        $out = [];
        foreach ($lines as $line) {
            $out[] = preg_replace('/^\s*\*\s?/', '', $line);
        }
        echo trim(implode("\n", $out)) . "\n";
    }
}

// ---------- arg parsing ----------------------------------------------------
$args = array_slice($argv, 1);
$inputs = [];
$outDir = null;
$keepStages = false;
$recursive = false;

for ($i = 0; $i < count($args); $i++) {
    $a = $args[$i];
    if ($a === '-h' || $a === '--help')           { show_help(); exit(0); }
    elseif ($a === '--stages')                    { $keepStages = true; }
    elseif ($a === '-r' || $a === '--recursive')  { $recursive = true; }
    elseif ($a === '--no-color')                  { set_color(false); }
    elseif ($a === '-o' || $a === '--output-dir') {
        $outDir = $args[++$i] ?? null;
        if ($outDir === null) { fail("$a needs an argument"); exit(2); }
    }
    elseif (str_starts_with($a, '--output-dir=')) { $outDir = substr($a, 13); }
    elseif (str_starts_with($a, '-'))             { fail("unknown flag: $a (try --help)"); exit(2); }
    else                                          { $inputs[] = $a; }
}

if (empty($inputs)) { fail("no input file or directory (try --help)"); exit(2); }

// ---------- file discovery -------------------------------------------------
const SKIP_DIRS = [
    'vendor',         // composer
    'node_modules',   // npm/yarn
    '.git', '.svn', '.hg',
    '.idea', '.vscode',
    'cache', 'tmp',
];

function collect_php_files(string $root, bool $recursive): array {
    if (is_file($root)) return [$root];
    if (!is_dir($root)) return [];

    if (!$recursive) {
        $files = glob(rtrim($root, '/') . '/*.php') ?: [];
        sort($files);
        return $files;
    }

    $files = [];
    $it = new RecursiveDirectoryIterator(
        $root,
        FilesystemIterator::SKIP_DOTS | FilesystemIterator::FOLLOW_SYMLINKS
    );
    $filter = new RecursiveCallbackFilterIterator($it, function ($current) {
        if ($current->isDir()) {
            return !in_array($current->getFilename(), SKIP_DIRS, true);
        }
        return strtolower($current->getExtension()) === 'php';
    });
    foreach (new RecursiveIteratorIterator($filter) as $f) {
        if ($f->isFile()) $files[] = $f->getPathname();
    }
    sort($files);
    return $files;
}

// Build the work list.
$workList = [];
foreach ($inputs as $input) {
    if (!file_exists($input)) { warn("skipping (not found): $input"); continue; }

    $absInput = realpath($input);
    $isDir = is_dir($absInput);

    if ($isDir && !$recursive) {
        info(dim("directory given without -r: processing top-level .php files only"));
    }

    $files = collect_php_files($absInput, $recursive);
    if (empty($files)) { warn("no .php files found in: $input"); continue; }

    $sourceRoot = $isDir ? $absInput : dirname($absInput);

    foreach ($files as $f) {
        $absF = realpath($f);
        if ($outDir !== null) {
            $relPath = $isDir ? substr($absF, strlen($sourceRoot) + 1) : basename($absF);
            $outFile = rtrim($outDir, '/') . '/' . $relPath;
            $stagesDir = $keepStages
                ? dirname($outFile) . '/stages_' . pathinfo($outFile, PATHINFO_FILENAME)
                : null;
            $bakPath = null;
        } else {
            $outFile = $absF;
            $stagesDir = $keepStages
                ? dirname($absF) . '/stages_' . pathinfo($absF, PATHINFO_FILENAME)
                : null;
            $bakPath = $absF . '.bak';
        }
        $workList[] = ['in' => $absF, 'out' => $outFile, 'stages' => $stagesDir, 'bak' => $bakPath];
    }
}

if (empty($workList)) { fail("nothing to process"); exit(1); }

// ---------- rewriter -------------------------------------------------------
function rewrite_evals_wrap(string $src): string {
    $needsPrefix = !preg_match('/^\s*<\?php/', $src);
    $tokSrc = $needsPrefix ? "<?php\n" . $src : $src;
    $tokens = token_get_all($tokSrc);
    $out = ''; $n = count($tokens);
    for ($i = 0; $i < $n; $i++) {
        $tok = $tokens[$i];
        if (is_array($tok) && $tok[0] === T_EVAL) {
            $out .= $tok[1]; $j = $i + 1;
            while ($j < $n) {
                $tj = $tokens[$j];
                $text = is_array($tj) ? $tj[1] : $tj;
                if (!is_array($tj) && $tj === '(') {
                    $out .= '(__catch('; $depth = 1; $j++;
                    while ($j < $n && $depth > 0) {
                        $tk = $tokens[$j];
                        $txt = is_array($tk) ? $tk[1] : $tk;
                        if (!is_array($tk)) {
                            if ($tk === '(') $depth++;
                            elseif ($tk === ')') {
                                $depth--;
                                if ($depth === 0) { $out .= '))'; break; }
                            }
                        }
                        $out .= $txt; $j++;
                    }
                    $i = $j; break;
                }
                $out .= $text; $j++;
            }
        } else {
            $out .= is_array($tok) ? $tok[1] : $tok;
        }
    }
    if ($needsPrefix) $out = preg_replace('/^<\?php\n/', '', $out, 1);
    return $out;
}

// ---------- prelude (runs in child PHP) -----------------------------------
$prelude = <<<'PHP'
<?php
function rewrite_evals_wrap(string $src): string {
    $needsPrefix = !preg_match('/^\s*<\?php/', $src);
    $tokSrc = $needsPrefix ? "<?php\n" . $src : $src;
    $tokens = token_get_all($tokSrc);
    $out = ''; $n = count($tokens);
    for ($i = 0; $i < $n; $i++) {
        $tok = $tokens[$i];
        if (is_array($tok) && $tok[0] === T_EVAL) {
            $out .= $tok[1]; $j = $i + 1;
            while ($j < $n) {
                $tj = $tokens[$j];
                $text = is_array($tj) ? $tj[1] : $tj;
                if (!is_array($tj) && $tj === '(') {
                    $out .= '(__catch('; $depth = 1; $j++;
                    while ($j < $n && $depth > 0) {
                        $tk = $tokens[$j];
                        $txt = is_array($tk) ? $tk[1] : $tk;
                        if (!is_array($tk)) {
                            if ($tk === '(') $depth++;
                            elseif ($tk === ')') {
                                $depth--;
                                if ($depth === 0) { $out .= '))'; break; }
                            }
                        }
                        $out .= $txt; $j++;
                    }
                    $i = $j; break;
                }
                $out .= $text; $j++;
            }
        } else {
            $out .= is_array($tok) ? $tok[1] : $tok;
        }
    }
    if ($needsPrefix) $out = preg_replace('/^<\?php\n/', '', $out, 1);
    return $out;
}

function parse_var_dump_string(string $dump): string {
    if (!preg_match('/^string\((\d+)\) "/', $dump, $m, PREG_OFFSET_CAPTURE)) {
        throw new RuntimeException("var_dump output not a string: " . substr($dump, 0, 80));
    }
    $len = (int)$m[1][0];
    $start = strlen($m[0][0]);
    return substr($dump, $start, $len);
}

$__stage = 0;
$__captures = [];
$__workDir = __WORKDIR__;

function __catch($code) {
    global $__stage, $__captures, $__workDir;
    $__stage++; $myStage = $__stage;
    ob_start(); var_dump($code); $dump = ob_get_clean();
    $captured = parse_var_dump_string($dump);
    $__captures[$myStage] = $captured;
    fwrite(STDERR, "[stage $myStage] " . strlen($captured) . " bytes\n");
    $rewritten = rewrite_evals_wrap($captured);
    if (strpos($rewritten, '__catch') === false) {
        return '/* final layer captured by dumper */';
    }
    return $rewritten;
}

register_shutdown_function(function() {
    global $__captures, $__workDir;
    foreach ($__captures as $i => $code) {
        file_put_contents("$__workDir/stage$i.php", "<?php\n" . $code);
    }
});
PHP;

// ---------- per-file processor --------------------------------------------
function process_file(array $job, string $prelude): array {
    ['in' => $inFile, 'out' => $outFile, 'stages' => $stagesDir, 'bak' => $bakPath] = $job;

    $src = file_get_contents($inFile);

    // Skip files that don't contain eval() — saves time on big trees.
    $tokens = @token_get_all($src);
    $hasEval = false;
    foreach ($tokens as $t) {
        if (is_array($t) && $t[0] === T_EVAL) { $hasEval = true; break; }
    }
    if (!$hasEval) {
        return ['status' => 'skipped', 'reason' => 'no eval()'];
    }

    $rewritten = rewrite_evals_wrap($src);
    $rewritten = preg_replace('/^\s*<\?php\s*/', '', $rewritten, 1);

    $workDir = sys_get_temp_dir() . '/dumper_' . bin2hex(random_bytes(4));
    mkdir($workDir);
    $thisPrelude = str_replace('__WORKDIR__', var_export($workDir, true), $prelude);
    $instrPath = $workDir . '/instrumented.php';
    file_put_contents($instrPath, $thisPrelude . "\n" . $rewritten);

    $desc = [0 => ['pipe', 'r'], 1 => ['pipe', 'w'], 2 => ['pipe', 'w']];
    $proc = proc_open('php ' . escapeshellarg($instrPath), $desc, $pipes);
    fclose($pipes[0]);
    stream_get_contents($pipes[1]);
    stream_get_contents($pipes[2]);
    fclose($pipes[1]); fclose($pipes[2]);
    proc_close($proc);

    $stageFiles = glob("$workDir/stage*.php") ?: [];
    natsort($stageFiles);
    $stageFiles = array_values($stageFiles);

    if (empty($stageFiles)) {
        array_map('unlink', glob("$workDir/*"));
        @rmdir($workDir);
        return ['status' => 'failed', 'reason' => 'no layers caught'];
    }

    $final = file_get_contents(end($stageFiles));

    if ($bakPath !== null) copy($inFile, $bakPath);

    if (!is_dir(dirname($outFile))) mkdir(dirname($outFile), 0777, true);
    file_put_contents($outFile, $final);

    if ($stagesDir !== null) {
        if (!is_dir($stagesDir)) mkdir($stagesDir, 0777, true);
        foreach ($stageFiles as $sf) {
            copy($sf, $stagesDir . '/' . basename($sf));
        }
    }

    array_map('unlink', glob("$workDir/*"));
    @rmdir($workDir);

    return [
        'status' => 'ok',
        'layers' => count($stageFiles),
        'final_size' => strlen($final),
        'orig_size' => strlen($src),
    ];
}

// ---------- main loop ------------------------------------------------------
$summary = ['ok' => 0, 'skipped' => 0, 'failed' => 0];
$startTime = microtime(true);

info(bold("dumper") . dim(" — processing " . count($workList) . " file(s)"));

$cwd = getcwd();
foreach ($workList as $job) {
    $relIn = $job['in'];
    if (str_starts_with($relIn, $cwd . '/')) {
        $relIn = substr($relIn, strlen($cwd) + 1);
    }

    fwrite(STDERR, dim('  • ') . $relIn . dim(' … '));

    $result = process_file($job, $prelude);
    $summary[$result['status']]++;

    switch ($result['status']) {
        case 'ok':
            fwrite(STDERR, green(sprintf(
                "%d layer%s, %d → %d bytes\n",
                $result['layers'],
                $result['layers'] === 1 ? '' : 's',
                $result['orig_size'],
                $result['final_size']
            )));
            break;
        case 'skipped':
            fwrite(STDERR, dim("skipped (" . $result['reason'] . ")\n"));
            break;
        case 'failed':
            fwrite(STDERR, red("failed (" . $result['reason'] . ")\n"));
            break;
    }
}

$elapsed = microtime(true) - $startTime;
fwrite(STDERR, "\n" . bold("Summary: "));
fwrite(STDERR, green("{$summary['ok']} ok") . dim(', '));
fwrite(STDERR, yellow("{$summary['skipped']} skipped") . dim(', '));
fwrite(STDERR, red("{$summary['failed']} failed"));
fwrite(STDERR, dim(sprintf(" in %.2fs\n", $elapsed)));

exit($summary['failed'] > 0 ? 1 : 0);